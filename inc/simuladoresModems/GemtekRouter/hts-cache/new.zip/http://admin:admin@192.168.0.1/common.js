//===  start common.js ===//

var countZero=0;

function CleanSingleKey(val)
{
	document.getElementById(val).value="";
}

function moreInfo(url) 
{
	var enhancePopup = true;
	if(enhancePopup) // usual case
	{
		fw=window.open(url, "fw", "resizable=yes,status=yes,scrollbars,HEIGHT=600,WIDTH=800");
		fw.focus();
	}
	else
	{
		self.location.href=url;
	}
}

function isBlank(s)
{
	for(i=0;i<s.length;i++)
	{
		c=s.charAt(i);
		if((c!=' ')&&(c!='\n')&&(c!='\t'))
		{
			return false;
		}
	}
	
	return true;
}

function isInitialZero(num)
{
	if((num.length > 1)&&(num.charAt(0) == '0'))
	{
		return true;
	}
	else
	{
		return false;
	}
}

function check_integer(a)
{
	var i;
	var c;
	
	if(a.length==0)
	{
		if((a>='0')&&(a<='9'))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		for(i=0; i<a.length; i++)
		{
			c=a.charAt(i);
		
			if((c>='0')&&(c<='9'))
			{
				continue;
			}
			else
			{
				return false;
			}
		}
	}
	
	return true;
}

function check_0Tof(a)
{
	var i;
	var c;
	
	if(a.length==0)
	{
		if(((a>='0')&&(a<='9'))||((a>='a')&&(a<='f'))||((a>='A')&&(a<='F')))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		for(i=0; i<a.length; i++)
		{
			c=a.charAt(i);
			
			if(((c>='0')&&(c<='9'))||((c>='a')&&(c<='f'))||((c>='A')&&(c<='F')))
			{
				continue;
			}
			else
			{
				return false;
			}
		}
	}
	
	return true;
}

function convertBinary(a)
{
	var num1;
	var num2;
	var currnum;
	currnum = 128;
	num1=a;

	if(num1 >= currnum)		/* next bit is "1" */
	{	
		if(countZero==0)		/* don't have a one yet */
		{	num2 = "1";
			num1 = num1 - currnum;
			currnum = currnum / 2;
		}
		else
		{
			countZero=0;		/* Reset mask flag*/
			return false;
		}
	}
	else				/* next bit is "0" */
	{		
		/* doesn't matter what u have before is zero or one */
		countZero=1;
		num2 = "0";
		currnum = currnum / 2;
	}

	for(p = 1; p <= 7; p++)
	{
		if(num1 >= currnum)	/* next bit is "1" */
		{
			if(countZero==0)		/*  have all ones*/
			{	num2 = num2 + "1";
				num1 = num1 - currnum;
				currnum = currnum / 2;
			}
			else				/*have both a zero and one before hand*/
			{
				countZero=0;	/* Reset mask flag*/
				return false;
			}
		}
		else			/* next bit is "0" */
		{	
			/* doesn't matter what u have before is zero or one */
			num2 = "0";
			countZero=1;
			currnum = currnum / 2;
		}
	}

	return true;
}

function check_ip(ip)
{
	var i;
	var n;
	var m;
	var c;
	if(ip.length > 0)
	{
		n = ip.split('.');
		if(n.length == 4)
		{	
			if(n[0]==127)
				return 1;
			if(!check_integer(n[0]))
				return 2;
			//if((isNaN(n[0]))||(n[0]<=0)||(n[0]>=224)||(isBlank(n[0]))||(isInitialZero(n[0])))
			if((isNaN(n[0]))||(n[0]<=0)||(n[0]>=224)||(isBlank(n[0]))) //hebe modify 2011.10.21
				return 1;
			if(!check_integer(n[1])) 
				return 2;
			//if((isNaN(n[1]))||(n[1]<0)||(n[1]>255)||isBlank(n[1])||(isInitialZero(n[1])))
			if((isNaN(n[1]))||(n[1]<0)||(n[1]>255)||isBlank(n[1])) //hebe modify 2011.10.21
				return 1;
			if(!check_integer(n[2])) 
				return 2;
			//if((isNaN(n[2]))||(n[2]<0)||(n[2]>255)||isBlank(n[2])||(isInitialZero(n[2])))
			if((isNaN(n[2]))||(n[2]<0)||(n[2]>255)||isBlank(n[2])) //hebe modify 2011.10.21
				return 1;
			if(!check_integer(n[3])) 
				return 2;
			//if((isNaN(n[3]))||(n[3]<=0)||(n[3]>255)||isBlank(n[3])||(isInitialZero(n[3])))
			if((isNaN(n[3]))||(n[3]<=0)||(n[3]>255)||isBlank(n[3])) //hebe modify 2011.10.21
				return 1;
		}
		else
		{	
			for(i=0; i<ip.length; i++)
			{
				c=ip.charAt(i);
			
				if((c>='0')&&(c<='9')||(c=='.'))
				{
					continue;
				}
				else
				{
					return 2;
				}
			}
			return 1;
		}
	}
	
	return 0;
}

function check_route_ip(ip,netmask)
{
	var i;
	var n;
	var m;
	
	if(ip.length > 0)
	{
		n = ip.split('.');
		m = netmask.split('.');
		if(n.length == 4)
		{	
			if(n[0]==127)
				return 1;
				
			//if((isNaN(n[0]))||(n[0]<1)||(n[0]>=224)||(isBlank(n[0]))||(isInitialZero(n[0]))||(!check_integer(n[0]))) 
			if((isNaN(n[0]))||(n[0]<1)||(n[0]>=224)||(isBlank(n[0]))||(!check_integer(n[0])))  //honest modify 2011.10.24
				return 1;
			
			//if((isNaN(n[1]))||(n[1]<0)||(n[1]>255)||isBlank(n[1])||(isInitialZero(n[1]))||(!check_integer(n[1])))
			if((isNaN(n[1]))||(n[1]<0)||(n[1]>255)||isBlank(n[1])||(!check_integer(n[1])))  //honest modify 2011.10.24
				return 1;
			
			//if((isNaN(n[2]))||(n[2]<0)||(n[2]>255)||isBlank(n[2])||(isInitialZero(n[2]))||(!check_integer(n[2]))) 
			if((isNaN(n[2]))||(n[2]<0)||(n[2]>255)||isBlank(n[2])||(!check_integer(n[2])))  //honest modify 2011.10.24
				return 1; 
			
			//if((isNaN(n[3]))||(n[3]<0)||(n[3]>=255)||isBlank(n[3])||(isInitialZero(n[3]))||(!check_integer(n[3]))) 
			if((isNaN(n[3]))||(n[3]<0)||(n[3]>=255)||isBlank(n[3])||(!check_integer(n[3]))) //honest modify 2011.10.24
				return 1;
				
			for (i=3;i>=0;i--)
			{
				if (m[i]!=255)
				{
					if ((m[i] & n[i])!=n[i])
						return 2;
				}
				else
					return 0;
			}
		}
		else
		{
			return 1;
		}
	}
	return 0;
}

function check_gateway(gateway)
{
	if(gateway == '0.0.0.0')
		return true;
	
	if ( check_ip(gateway)!=0 )
		return false;
	else
		return true;
}

function check_netmask(mask)
{
	var i;
	var n;
	var temp;

	countZero=0;
	if(mask.length > 0)
	{
		n=mask.split('.');

		if(n.length==4)
		{
			if(n[0] == '0')
				return 2;
			for(i=0; i<4; i++)
			{
				if((isBlank(n[i]))||(isNaN(n[i])))
					return 3;
					
				if(!check_integer(n[i]))
					return 1;
					
				if((n[0]<128)||(n[i]>255))
					return 2;
			}
			if((convertBinary(n[0]))&&(convertBinary(n[1]))&&(convertBinary(n[2]))&&(convertBinary(n[3])))
			{
				return 0;
			}
			else
			{
				return 2;
			}
		}
		else
		{
			return 3;
		}
	}
	else 
		return 3;
		
	return 0;
}

function check_the_same_subnet(ip1, ip2, netmask)
{
	var i;
	var ip1_partition = ip1.split('.');
	var ip2_partition = ip2.split('.');
	var netmask_partition = netmask.split('.');
	var check_partition;
	
	if( (ip1_partition.length == 4) && (ip2_partition.length == 4) && (netmask_partition.length == 4) )
	{
		for (i=3;i>=0;i--)
		{
			if( (ip1_partition[i] & netmask_partition[i]) != (ip2_partition[i] & netmask_partition[i]) )
			{
				return false;
			}
		}
		
		return true;
	}
	else
	{
		return false;
	}
}

//Add by hebe 2011.10.24
function check_broadcast_ip_mask(ip1, netmask ,ip2)
{
	var i;
	var ip1_partition = ip1.split('.');//Gateway IP
	var ip2_partition = ip2.split('.');//Wan IP
	var netmask_partition = netmask.split('.');
	var check_partition;
	
	if( (ip1_partition.length == 4) && (netmask_partition.length == 4) )
	{
		for (i=3;i>=0;i--)
		{
			if (netmask_partition[i] == 255)
			{
				continue;
			}
			var tmp1 = 256-netmask_partition[i];
			var tmp2 = Math.floor(ip2_partition[i]/tmp1);
      var subnet = tmp2*tmp1;
      var broadcast = (tmp2+1)*tmp1-1;
			if ( (ip1_partition[i] > broadcast) || (ip1_partition[i] < subnet))
			{
				//alert("i:" + i);
				//alert(ip1_partition[i]);
				//alert(check_partition);
				return 1;
			}
		}
		return 0;
	}
}
//Add end

function check_mac_plus(mac)
{
        var i;
        var n;
        var count=0;
        var ff_valid=0;
        var zero_valid=0;
        var odd_valid=0;
        var valid=0;
        var odd_array="02468AaCcEe";

        if(mac.length > 0)
        {
                n = mac.split(':');

                if(n.length==6)
                {
                        if (n[0]!="*")
                        {
                                for (i=0;i<odd_array.length;i++)
                                {
                                        if (n[0].charAt(1) == odd_array.charAt(i))
                                                odd_valid=1;
                                        else
                                                continue;
                                }
                        }
                        else
                                odd_valid=1;

                        for(i=0; i<6; i++)
                        {
                                if (n[i]=="*")
                                {
                                        count++;
                                        if (count>5)
                                                return false;

                                        continue;
                                }
                                else
                                {
                                        if((isBlank(n[i]))||(!check_0Tof(n[i]))||(n[i].length != 2))
                                        {
                                                return false;
                                        }
                                }
                        }

                        for(i=0; i<6; i++)
                        {
                                if(((n[i].charAt(0)=='f')||(n[i].charAt(0)=='F'))&&((n[i].charAt(1)=='f')||(n[i].charAt(1)=='F')))
				{
                                        continue;
				}
                                else
                                {
                                        ff_valid=1;
                                        break;
                                }
                        }

			for(i=0; i<6; i++)
                        {
                                if((n[i].charAt(0)=='0')&&(n[i].charAt(1)=='0'))
				{
                                        continue;
				}
                                else
                                {
                                        zero_valid=1;
                                        break;
                                }
                        }
                        if((ff_valid==1)&&(zero_valid==1)&&(odd_valid==1))
                        {
                                return true;
                        }
                        else
                        {
                                return false;
                        }
                }
                return false;
        }
        return true;
}

function check_mac(mac) //Caspar modified for check error feature 20100324
{	//0:no error 1:mac length error 2:mac address error 
	var i;
	var n;
	var ff_valid=0;
	var zero_valid=0;
	var odd_valid=0;
	var valid=0;
	var odd_array="02468AaCcEe";
	
	if(mac.length > 0)
	{
		n = mac.split(':');

		if(n.length==6)
		{
			for (i=0;i<odd_array.length;i++)
			{
				if (n[0].charAt(1) == odd_array.charAt(i))
					odd_valid=1;
				else
					continue;	
			}

				
			for(i=0; i<6; i++)
			{
				if((isBlank(n[i]))||(!check_0Tof(n[i]))||(n[i].length != 2))
				{
					return 2;
				}
			}

			for(i=0; i<6; i++)
			{
				if(((n[i].charAt(0)=='f')||(n[i].charAt(0)=='F'))&&((n[i].charAt(1)=='f')||(n[i].charAt(1)=='F')))
				{
					continue;
				}
				else
				{	
					ff_valid=1;
					break;
				}
			}

			for(i=0; i<6; i++)
			{
				if((n[i].charAt(0)=='0')&&(n[i].charAt(1)=='0'))
				{
					continue;
				}
				else
				{	
					zero_valid=1;
					break;
				}
			}

			if((ff_valid==1)&&(zero_valid==1)&&(odd_valid==1))
			{
				return 0;
			}
			else
			{
				return 2;
			}
		}
		else
		{
			return 1;
		}
	}
	
	return 0;
}

function check_port(a)
{
	if(a.length > 0)
	{
		if((isNaN(a))||(a<1)||(a>65535)||(!check_integer(a))||(isInitialZero(a)))
		{
			return false;
		}		
	}
	
	return true;
}

function check_integer_range(inputValue, minValue, maxValue)
{
	if(inputValue.length > 0)
	{
		if((!check_integer(inputValue))||(inputValue<minValue)||(inputValue>maxValue)||(isInitialZero(inputValue)))
		{
			return false;
		}		
	}

	return true;
}

function check_overlap(s, e, s_ed, e_ed)
{
	if(((parseInt(s)>=parseInt(s_ed))&&(parseInt(s)<=parseInt(e_ed)))||((parseInt(e)>=parseInt(s_ed))&&(parseInt(e)<=parseInt(e_ed))))
	{
		return false;
	}
	
	if(((parseInt(s_ed)>=parseInt(s))&&(parseInt(s_ed)<=parseInt(e)))||((parseInt(e_ed)>=parseInt(s))&&(parseInt(e_ed)<=parseInt(e))))
	{
		return false;
	}
	
	return true;
}

function merge_ip(target, item1, item2, item3, item4)
{
	var target_item=document.getElementById(target);
	var value1=document.getElementById(item1).value;
	var value2=document.getElementById(item2).value;
	var value3=document.getElementById(item3).value;
	var value4=document.getElementById(item4).value;
	target_item.value=value1+"."+value2+"."+value3+"."+value4;
	
	return true;
}

function merge_mac(target, item1, item2, item3, item4, item5, item6)
{
	var target_item=document.getElementById(target);
	var value1=document.getElementById(item1).value;
	var value2=document.getElementById(item2).value;
	var value3=document.getElementById(item3).value;
	var value4=document.getElementById(item4).value;
	var value5=document.getElementById(item5).value;
	var value6=document.getElementById(item6).value;
	target_item.value=value1+":"+value2+":"+value3+":"+value4+":"+value5+":"+value6;
	
	return true;
}


function Show_error(item_name, err_msg)
{
	var errObj = document.getElementById("id_errtbl");
	var itemstring=top.err_item;
	var descriptionstring=top.err_description;
	//alert(itemstring+" : "+descriptionstring);
	errObj.innerHTML = '<hr>';
	errObj.innerHTML += "<p>"+itemstring+" "+item_name+"<br>"+descriptionstring+" "+err_msg+"</p>";
	errObj.innerHTML += '<hr>';
	errObj.style.display="";
	window.scroll(0,0);
}


function Show_error_3(item_name, err_msg, err_content)
{
	var errObj = document.getElementById("id_errtbl");
	var itemstring=top.err_item;
	var descriptionstring=top.err_description;
	var CONTENTSstring=top.err_CONTENTS
	//alert(itemstring+" : "+descriptionstring);
	errObj.innerHTML = '<hr>';
	if(err_content.length!=0)
		errObj.innerHTML += "<p>"+itemstring+" "+item_name+"<br>"+descriptionstring+" "+err_msg+"<br>"+CONTENTSstring+" "+err_content+"</p>";
	else
		errObj.innerHTML += "<p>"+itemstring+" "+item_name+"<br>"+descriptionstring+" "+err_msg+"</p>";
	errObj.innerHTML += '<hr>';
	errObj.style.display="";
	window.scroll(0,0);
}

//add
function Show_WizardError(item_name, err_msg)
{
	var errObj = document.getElementById("id_errtbl");
	var itemstring=top.err_item;
	var descriptionstring=top.err_description;
	errObj.innerHTML = '<hr>';
	errObj.innerHTML += "<p>"+itemstring+" "+item_name+"<br>"+descriptionstring+" "+err_msg+"</p>";
	//errObj.innerHTML += "<p>ERROR: "+item_name+"<br>"+"description: "+err_msg+"</p>";
	errObj.style.display="";
}

function Show_WizardError2(item_name)
{
	var errObj = document.getElementById("id_errtbl");
	var itemstring=top.err_item;
	var descriptionstring=top.err_description;
	errObj.innerHTML = '<hr>';
	errObj.innerHTML += "<p>"+itemstring+" "+item_name;
	//errObj.innerHTML += "<p>ERROR: "+item_name+"<br>"+"description: "+err_msg+"</p>";
	errObj.style.display="";
}

function translate_strWrite(category, s_number ) {
        document.write(eval(category+"["+s_number+"]"));
}

function setButtonValue(id, category, s_number) {
        document.getElementById(id).value=eval(category+"["+s_number+"]");
}

function translate_str(category, s_number) {
        return eval(category+"["+s_number+"]");
}

function Hide_error()
{
	var errObj = document.getElementById("id_errtbl");
	errObj.style.display="none";
}

function Escape_String(item_string)
{
	var stringtmp=escape(item_string);
	var i=0;
	for (i=0;i<stringtmp.length;i++)
	{	
		if (stringtmp.charAt(i)=='%'&& stringtmp.charAt(i+1)=='u')
			return false;
	}
	return true;
}

function convert(num)
{
	var num1;
	var num2;
	var currnum;
	currnum = 128;
	num1 = eval(num);
	if(num1 >= currnum)
	{
		num2 = "1";
		num1 = num1 - currnum;
		currnum = currnum / 2;
	}
	else
	{
		num2 = "0";
		currnum = currnum / 2;
	}		
	for (p = 1; p <= 7; p++)
	{
		if(num1 >= currnum)
		{
			num2 = num2 + "1";
			num1 = num1 - currnum;
			currnum = currnum / 2;
		}
		else
		{
			num2 = num2 + "0";
			currnum = currnum / 2;
		}
	}
	return num2;
}

function Changelink(url,helpurl)
{
	top.frames[2].location.href = url;
	top.frames[3].location.href = "./help/"+helpurl;
}

function check_ascii(a)
{
	var i;
	var c;
	
	if(a.length==0)
		return true;
	else
	{
		for(i=0; i<a.length; i++)
		{
			c=a.charCodeAt(i);
		
			if((c>='32')&&(c<='126'))
			{
				continue;
			}
			else
			{
				return false;
			}
		}
	}
	return true;
}

function rm_start(item)
{
	var itemObj = document.getElementById(item);
	if (itemObj.value.length!=0)
		itemObj.value="";
}

//Add by Honest 2011.10.24
function ip_normalize_0(ip)
{
	var ip_tmp = ip.split('.');
	
	if (ip_tmp.length!=4)
		return ip;
		
	var ip_s = ip.split('.', 4);

	if(ip_s.length!=4)
		return ip;

    return parseInt(ip_s[0],10) + "." +
           parseInt(ip_s[1],10) + "." + 
           parseInt(ip_s[2],10) + "." + 
           parseInt(ip_s[3],10);
}
//Add end

function wifipskcheck(psk)
{
	for (i=0; i<psk.length; i++)
	{
		var c;
			
		c=psk.charAt(i);
		
		if ((c=='<') || (c=='>') || (c=='\"') || (c=='\'') || (c=='\\') || (c=='&') || (c==';') || (c==' ') || (c=='|'))
		{
			return false;
		}
	}
	return true;
}

function showhide(element, sh)
{
    var status;
    var nofunction;
    if (sh == 1) {
        status = "block";
        nofunction = "false";
    }
    else {
        status = "none"
        nofunction = "true"
    }

        if (document.getElementById)
        {
                // standard
                document.getElementById(element).style.display = status;
                document.getElementById(element).style.disabled = nofunction;
        }
        else if (document.all)
        {
                // old IE
                document.all[element].style.display = status;
                document.all[element].style.disabled = nofunction;
        }
        else if (document.layers)
        {
                // Netscape 4
                document.layers[element].display = status;
                document.layers[element].style.disabled = nofunction;
        }
}

function isValidIpAddressnew(address)
{
        var i = 0;
        if ( address == '0.0.0.0' || address == '255.255.255.255' )
                return false;

        addrParts = address.split('.');

        if ( addrParts.length != 4 )
                return false;

        for (i = 0; i < 4; i++)
        {
                if (isNaN(addrParts[i]) || addrParts[i] == "")
                        return false;

                num = parseInt(addrParts[i]);
                if ( num < 0 || num > 255 )
                        return false;

                if(i==0)
                {
                        if(num == 0 || num == 127)
                                return false;

                        if (num > 223)  // 1-223 is valid.
                                return false;
                }

                if(i==3)
                {
                        if(num==0 || num==255)
                                return false;
                }
        }
        return true;
}

function isValidSubnetMasknew(mask)
{
   var i = 0, num = 0;
   var zeroBitPos = 0, oneBitPos = 0;
   var zeroBitExisted = false;

   if ( mask == '0.0.0.0' )
      return false;

   maskParts = mask.split('.');
   if ( maskParts.length != 4 )
                return false;

   for (i = 0; i < 4; i++)
   {
      if ( isNaN(maskParts[i]) == true )
         return false;
      num = parseInt(maskParts[i]);
      if ( num < 0 || num > 255 )
         return false;
      if ( zeroBitExisted == true && num != 0 )
         return false;
      zeroBitPos = getLeftMostZeroBitPos(num);
      oneBitPos = getRightMostOneBitPos(num);
      if ( zeroBitPos < oneBitPos )
         return false;
      if ( zeroBitPos < 8 )
         zeroBitExisted = true;
   }
   // Aries add ,  submask can't be 255.255.255.255
   if ((maskParts[3]=='255') && (maskParts[2]=='255') && (maskParts[1]=='255') && (maskParts[0]=='255'))
                 return false;
   return true;
}

function getLeftMostZeroBitPos(num) {
   var i = 0;
   var numArr = [128, 64, 32, 16, 8, 4, 2, 1];

   for ( i = 0; i < numArr.length; i++ )
      if ( (num & numArr[i]) == 0 )
         return i;

   return numArr.length;
}

function getRightMostOneBitPos(num) {
   var i = 0;
   var numArr = [1, 2, 4, 8, 16, 32, 64, 128];

   for ( i = 0; i < numArr.length; i++ )
      if ( ((num & numArr[i]) >> i) == 1 )
         return (numArr.length - i - 1);

   return -1;
}

function check_char(s){
        var reg=/[\\']+/g;
        if(reg.test(s)){
                alert("Invalid character");
                return false;
        }
        else
                return true;
}

//===  end common.js ===//
